==========================================================================================
[Install Notes]

Place the pak file in your quake2\baseq2\ directory.

"Fixed so it will check for pak0 through pak9 instead of starting at pak0
 and stopping when it gets a miss." 

Recommended baseq2\ order:
* pak0.pak      - id Quake 2 base.
* pak1.pak      - id Quake 2 point release.
* pak2 - 8.pak  - (Future addons)
* pak9.pak      - OptiMizer Pak.

(If you encounter multiple filenames, rename one pak file.)
When you place this pak in your baseq2\ directory, quake2 can access it
in all "games" you run. Like CTF or other modifications.

Released : 16/10 2000
	
==========================================================================================
[Pak Info]

OptiMizer  Pak
Filename 		: Optipak.zip
Version  		: 9.3
Base Used		: Quake2 v3.21
Author   		: OptiMizer
Email    		: OptiMizer@quakemail.com
Homepage 		: Http://optimizer.cjb.net 
ClanPage 		: Http://znitz.spiff.sytes.net/q2
Irc	 		: #znitz
                         
==========================================================================================
[Stuff In The Pak]               
                        
* New Inventory
* New RL-Explodes
* New Sounds.
* New Conback.
* New Menu graphic
* New Crosshairs
* New Textures
* New RL-Skin
* New RG-Skin
* Match1.bsp
* ztn2dm3.bsp
* BrightSkins
* Quake1 font(conchars)
* Fixed Reversed laser model texture

==========================================================================================
[Construction]

Base                    : My computer
Editor(s) used          : Photoshop, Paint Shop Pro and Paint.
Build time 		: Never stopped
System			: AMD - Athlon 1400/512MB/Windows 2000

==========================================================================================
[Latest Changes]

* Updated the rocketskin to work properly in nocheat. (thnx Cato)
* Znitz inventory
* Fixed conchars
* Changed old "OptiMizer conback" to Znitz Logo

==========================================================================================
[Future]

Allways some bugfix or new stuff like graphic, sound ect.

==========================================================================================
[Credits]

Quake3 Arena - Sounds.
[HOR]Cato - *.wal plugin and some nice sounds.
Section8 - Textures.
Muffin - Black railgun, MH-Sound, demo1.dm2 and armorsound.
Plus30 - Body, Jacket and Combatarmor
OptiMizer - for making this great pak.

==========================================================================================
[No Credits]

Spikes users, fejknickers....gotta hate them all >:D

==========================================================================================