   +---------------------+
   | Quake 2 Text ReadMe |
   |  by [CGS]Echinus    |
   +---------------------+

Basically, I've decided to write some *simple* instructions because
otherwise, people might make things difficult for themselves...

To add a character either:

1. Type the normal characters in with the keyboard
2. Position the cursor by using the arrow keys or by clicking where
   you want the letters to start on the bottom section, and double
   click on the letters in the top section.
3. Click on a letter in the top section, and double click where you
   want the letter in the bottom section.
4. Drag the character from the top to the bottom section.

N.B. There is a new feature from version 1.2 that lets you hold right
     mouse button (as well as the left one) while dragging to fill all
     the boxes you drag the mouse over with the current character.
     This makes it easier to do lines of the same character.

To use the config manager:

1. Select manager from the config menu
2. Type the key you wish to use to run one of your config files
3. Click the button labelled "Set this key to exec a config"
4. Choose the config file you wish to run
5. Repeat steps 2-4 if neccessary
6. Save the file in your "quake2\baseq2" directory
7. From the Quake 2 console, type "exec myconfig.cfg"

Thanks to:

  * Sam
  * [SLOB]KK
  * [CGS]Assassin8
  * [WGF]GuRKe
  * RebelX

Well, please help me to make this program successful - email or icq me
with any suggestions or problems.  I'll try my best to help

  Chris Pearson aka [CGS]Echinus
  ICQ : 27132992
  Email : chris@at-dot.freeserve.co.uk
  URL : http://www.visitweb.com/q2text