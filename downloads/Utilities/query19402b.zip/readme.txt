======================================
          Server Query BETA
              v1.94.00
          31 October, 2003

     http://www.serverquery.com/
     Email: nathan@ausgamers.com
======================================

SUPPORTED GAMES: Aliens vs Predator 2, America's Army: Operations, Battlefield 1942, Battlefield 1942: Secret Weapons Demo, C&C Renegade, Daikatana, Elite Force 2, Enemy Territory, Global Operations, Gore, Half-Life, IGI-2: Covert Strike, Jedi Knight II: Jedi Outcast, Kingpin: Life Of Crime, Medal of Honour: Allied Assault, Medal of Honour: Allied Assault Spearhead, Medal of Honour: Allied Assault Spearhead Demo, Need For Speed: Hot Pursuit 2, Neverwinter Nights, Operation Flashpoint, Quake, Quake III: Arena, QuakeWorld, Return to Castle Wolfenstein, Rune, Serious Sam, Serious Sam 2, Sin, Soldier Of Fortune, Soldier of Fortune II: Double Helix, Tribes, Tribes II, Unreal, Unreal Tournament, Unreal Tournament 2003, V8 Challenge, Vietcong


==RELEASE NOTES==

This release adds support for a few miscellaneous games.  More importantly, this release switches to a more modular method of managing server types so updates should be easier and more frequent in the future.

Unfortunately, this release partially breaks compatibility with SQ's ini files - you will need to reconfigure the paths to your installed games after installation.


==CONTRIBUTORS==

- Kingsley Foreman (Info & icons on various gametypes)



==THANKS==

- My dedicated group of BETA TESTERS
- Anyone who's ever sent in a bug report
- Everyone who uses this thing, if it weren't for you guys I would have given up long ago *g*
- AusGamers, for web hosting



==KNOWN BUGS==

- The 'mouse wheel' code to change servers doesn't work on all PCs
- Server 'UNREACHABLE' message uses a forced value of 5secs; doesn't respond to timeout setting
- "Sort LAN servers by type" can cause lock-ups 


==TO DO==

- Button bar for commonly used actions
- Query multiple servers (?)
- eliminate 'maxhashes', ie allow infinite (up to total memory avail) hashes
- Drag and drop servers and lists
- Implement option to allow mouse wheel to not collapse lists
- 'Refresh' of LAN list permanently removes all servers
- Re-add "buddy" search
- Player profiles
- Cmd line paramaters on a per-server basis
- Options on the SQ system tray icon (open, close, connect?)
- Allow import of QSTAT files (ie locally, not via http)
- RCON window 
- Baldurs Gate 2 support (??)
- Select games to show
- Linux port
- switching to hlds when in sublist lan mode causes a lockup when switch back
- 'Delete' key to delete servers
- 'Group by Gametype' doesn't work for QStat/WireView lists
- Multiple 'games' associated with single game type (eg Half-Life, CS Retail)
- Monitor multiple games while waiting for free spot
- ICQ integration (set away, and away message) on connect
- Minimise SQ on connect
- Show "lock" icon on passworded servers
- Wait for spot feature on servers with "reserved" spots - on player count < full, wait for players to drop below current level
- Show special icon on servers which are full
- Show CVARs at all times
- Fix daikatana demo (doesn't show icon properly)
- Add daikatana retail support (v1.0/1.2)
- Option at startup to re-select the current server when SQ was last closed 

Suggestions? Email me.



==GAME TYPES==
1: Quake2  [Q2S]
2: Sin  [SNS]
3: QuakeWorld  [QWS]
4: Half-Life  [HLS]
5: Tribes  [TBS]
6: Quake3  [Q3S]
7: Unreal  [UNS]
8: Quake  [QS]
9: Kingpin  [KPS]
10: Unreal Tournament  [UNS]
11: Rune  [RNS]
12: Soldier Of Fortune  [SFS]
13: Daikatana  [DKS]
14: Quake3 1.27 (NOW UNUSED)
15: Gore  [GRS]
16: Tribes 2  [T2S]
17: Return to Castle Wolfenstein Demo  [RWD]
18: Return to Castle Wolfenstein  [RWS]
19: MOHAA Demo  [MHD]
20: MOHAA  [MHS]
21: MOHAA 1.0  
22: Serious Sam  [SMS]
23: Serious Sam 2  [S2S]
24: Serious Sam 2 Demo  [S2D]
25: C&C Renegade Demo  [RGD]
26: Global Operations Demo  [GOD]
27: C&C Renegade  [RGS]
28: Jedi Knight 2  [J2S]
29: Soldier of Fortune II: Double Helix Demo [SF2D]
30: Soldier of Fortune II: Double Helix [SF2S]
31: Alien vs Predator 2 [AP2S]
32: Neverwinter Nights [NWS]
33: V8 Supercar Challenge [VCS]
34: America's Army [AAS]
35: Battlefield 1942 [BFS]
36: Unreal Tournament 2003 [UT2S]
37: VietCong Demo [VCGD]
38: Tactical Ops [TACS]
39: IGI-2: Cover Strike [IG2S]



==CHANGES==
19415 -> 19400
- Whole new method of managing server types
- Couple of new games added

19314 -> 19315
- Added VietCong Demo, Tactical Ops, IGI2 support (thanks Kingsley Foreman)

19312 -> 19314
- Added Unreal Tournament 2003 support

19311 -> 19312
- Added Battlefield 1942 support

19310 -> 19311
- Fixes crash bug caused by buddy list

19309 -> 19310
- Check on startup for a prior instance of SQ, if active switch to that instance (thanks DuXa & Huma)
- Fixed SOF2 1.01 player list
- Press F5 to refresh current list (thanks Duxa & Huma)
- Basic buddy support
- Fixed DoD 3.0 player list

19308 -> 10309
- America's Army support
- V8 supercar Challenge support
- Fixed NWN support

19307 -> 19308
- NeverwinterNights support
19306 -> 19307
- SOF2 Full support
- AVP2 support (contributed by: Kingsley Foreman)

19305 -> 19306
- Added SOF2 MP TEST support

19304 -> 19305
- Added JK2 support

19303 -> 19304
- Fixed unreal.dll crash bug

19302 -> 19303
- Added Global Ops Demo support
- Added Renegade Full support
- Fixed display of Renegade stats in server list

19301 -> 19302
- Added mod support to schemes

19300 -> 19301
- Moved strings into separate .h file, re-unified resource file
- Strengthened DDE decoding algorithm

19226 -> 19300
- New version #
- Added IE scheme support (ie x-game://ip:port/ support)
- Window will now move back on-screen if necessary

19225 -> 19226
- Moved QSTAT, GameSpy types to DLL's (no need to recompile .exe for new gametypes)

19224 -> 19225
- Fixed player count on status bar
- Added C&C: Renegade Demo support
- Fixed pixelated icon in GA release

19223 -> 19224
- Added special MOHAA 1.0 support (different port used than 1.1 patch)
- Added Serious Sam, Serious Sam 2, Serious Sam 2 Demo support

19222 -> 19223
- Fixed RTCW connection issue
- Changed status to show numplayers/maxplayers for current list
- Added MOHAA, MOHAA Demo support
- Pressing Insert brings up Add Server dialog

19221 -> 19222
- Added RTCW Full version support
- Updated Half-life DLL to recognise AdminMod's "reserve_slots" CVAR and adjust the maxplayers value as required
- Cleaned up some dialog boxes
- Fixed tab-order on all dialog boxes
- Fixed crash when pressing DELETE key on a server that can not be deleted

19220 -> 19221
- Fixed "-128" player bug in halflife.dll when viewing a HLTV server
- Fixed "Add Online Lists" program logic
- Fixed crash bug when using Q3 master
- Re-added Q3Master support
- Added RTCW Demo and QuakeWorld master support

19219 -> 19220
- Fixed halflife.dll to show Timelimit for Counter-Strike (and other HL mods?) when "Show Extra Variables" is enabled
- Added support for pressing "Delete" to delete servers/lists
- Added option to toggle LAN list on/off
- Added Return to Castle Wolfenstein Demo support

19218 -> 19219
- Fixed "add server" hostname freeze/crash 
- Daikatana no longer adds "+set game" to command line (thanks: Christian Hoeier)
- Modified data sorting routines to decrease cpu usage 
- Added configuration option to refresh current list every X seconds (sorry, forgot who suggested this)
- Fixed Aust UT list not work (.zip packaging problem)  
- Really fixed quake3 'no icon' issue

- 19217 -> 19218
- Daikatana fixes (icon, incorrect reading of values)  (thanks: Christian Hoeier)
- Quake3 'no icon' fix  (thanks: Various)

19216 -> 19217
- Fixed qstat.c to support unreal tournament gamespy master lists

19215 -> 19216
- Option to play audio alert when waiting for free spot on server
- Improved DNS performance
- When pinging entire list, will try a server up to three times instead of just once
- Add Server dialog box now can add multiple servers from one invocation
- Add Server dialog box "remembers" last used game type
- Fixed "Delete List" causes SQ to crash
- Removed "Quake3 1.17/1.27" distinction
- Added "IP" to server info pane
- Switched DLLs to use MSVCRT for functions; significantly reduced file sizes

19214 -> 19215
- Fixed incorrect connection string for Quake2, QW (possibly others)
- Fixed about window
- Increased receive-buffer size
- SQ now adds "[x/y players]" to server description string
- Fixed Tribes2 reading too far into buffer due to malformed packets

19213 -> 19214
- Tribes2 support

19212 -> 19213
- Added 'WireView' serverlist support (as used by Wireplay)
- Unreal DLL can now switch automatically to Rune gametype

19211 -> 19212
- Added more options to 'refresh/timeout' selections in configuration dialog
- Added separate internet/lan refresh/timeout settings
- Fixed: LAN sublists being saved to default.sq
- SQ now defaults to opening 'Favourites' list at startup (or 'LAN' if no net connection)

19210 -> 19211
- HTTP code now always requests new data (get around bad proxies)
- Added Q3 OSP team support
- Added option to not display 'All Servers' in dual-pane

19209 -> 19210
- Fixed single-pane interface position
- 'All Servers' are no longer shown in single-pane
- Removed necessary restart when switching interfaces
- Cleaned up general configuration screen
- Added Gore Test support

19208 -> 19209
- Added 'Extra Info' option to general configuration (turn on extra server variables)
- Added Quake2 L-fire team cvars support
- Re-added general 'extra' variables (fraglimit, timelimit, capturelimit)

19207 -> 19208
- Fixed systray icon disappearing
- Added Q3F team listing support

19206 -> 19207
- Fixed crash bug in recv_packet thread
- Fixed crash bug in tribes dll

19205 -> 19206
- Added second thread for receiving status packets
- Pings now use a higher-resolution timer when available

19204 -> 19205
- Added Rune support
- Fixed Unreal-engine support on LAN
- Fixed Unreal connection method (SQ now accepts path to Unreal-based games)
- Implemented different method of tracking servers (to allow for filtering)
- (Properly) fixed website links
- Implemented full server-listing, off the 'Servers' root list
- Added status bar
- Added progress bar for use whilst pinging servers
- Separate support for 1.17 and 1.27 based Quake3 servers
- Quake3: Fortress servers now display team scores
- On missing game, after configuring path Query will attempt to connect to server again

19203 -> 19204
- Fixed System Tray icon preventing SQ from saving window positions
- Fixed System Tray icon not disappearing when Systray configuration changed from on to off
- Added version info for 1.17,1.27 to quake3.dll

19202 -> 19203
- Fixed crash bug in PingAllServers() 
- Fixed bug linking 'Update hostnames' to the (now defunct) 'PingAllServers' feature
- Fixed 'Asterisk' button not linking to SQ website under Win2000
- (hopefully) fixed 'lagged DNS' problem (thanks: Slydog)
- Fixed inaccurate 'first ping' after changing the selected server


19201 -> 19202
- Added 'sleep' command to ResolveName() function; should help Win9x users
- Fixed Server Properties window  not working

19200 -> 19201
- Added 'Favourites' folder; with hooks to directly cut&paste into it
- Added 'Update Hostnames' option; if enabled, the names displayed in the server list will automatically update to reflect the 'real' name of the server

19298 -> 19200
- Added 'theoretical' support for multiple parent lists
- A pop up box now appears during the first DNS query; if the 'Cancel' button on this box is clicked or five seconds expires, subsequent domainname lookups will automatically fail
- Right-clicking a server no longer causes the parent list to redraw/resort
- Due to new DNS code, disabled the "disable name resolution on crash" code
- Added grey icon for 16 color display
- Removed 'View DM Flags' from server menu (replaced with a separator)
- SQ Chat feature removed

19197 -> 19198
- Added 'Copy IP' to server context menu (similar to 'Copy Desc')
- Added 'Average Ping' column
- Fixed Unreal/UT support for non-standard ports and LAN servers
- Fixed incorrect detection of shift key setting (to disable DNS)
- Fixed GameSpy master code to support QuakeWorld

19196 -> 19197
- Fixed bug in netcode that was preventing http proxy from working correctly 
- Fixed 'ghost' QuakeWorld server at start up
- Holding 'shift' down at start up will disable DNS
- LAN servers change hostnames automatically
- Added /NET command line switch to force DNS
- Fixed possible crash bug in PingAllServers()

19195 -> 19196
- Fixed servers in dual-pane not updating their names (w00t!)
- Size of table entries is now variable (used to be fixed to 288 bytes - 32key/256value - new default 16key/16value)
- Changed servers to use tables for player storage
- Added (untested) HTTP proxy support (to go through web firewalls)
- Began clean up of UI code
- Fixed incorrect HTTP 1.1 code

19194 -> 19195
- gspymaster.dll now pings servers after refreshing in dual-pane mode

19193 -> 19194
- Removed 'Show Advanced Server Info' option from Configure menu
- ListView column widths are now saved/restored
- Fixed list-refresh bug in dual pane view
- In dual pane, clicking on 'Server Name', 'Ping', 'Players' or 'Map' will sort the server list accordingly
- Prevented 'TVN_SELCHANGED' from firing during shutdown process (giving a speed increase during shutdown, esp with large numbers of lists)
- halflife.dll now correctly uses "+password" instead of "+set password"

19192 -> 19193
- Added Daikatana demo support to quake2.dll
- Limited each server to only send a packet once every 100ms; this seems to prevent the lock up/UI 'lag outs' I was experiencing (debugging seemed to indicate that the socket status was switching to 'not writable', causing a lag/lock up on the next sent packet)
- Main window is now hidden during shutdown (so SQ 'appears' to close quicker) [Update:  disabled for debugging purposes]
- 'Net connection not present' dialog box disabled (Thanks: Boba)
- 'Fixed' HTTP connection code, as it no longer worked with the QGL server
- New feature - 'Add Online Lists'.  Downloads a list of available online lists (supports QSTAT and GSPYMASTER); checks which are currently not in the list, and provides a box to add the lists.  
- Fixed unreal.dll to correctly display map names in dual-pane view
- Added '+set fs_game' support to quake3.dll
- Fixed bug in HTTP code that was losing http headers

19191 -> 19192
- Fixed lagged 'restore window' bug
- Fixed problem in display of Unreal/UT player & maxplayer settings
- Set dual pane to default on new installations
- Added primary (more elegant) test to determine whether internet access is available
- Allowed other IP addresses to be entered when connecting to chat server
- Chat connection will abort if sendto() returns an error (eg due to disconnection from network)

19190 -> 19191
- Fixed lagged typing bug
- Received messages no longer disappear if the userlist updates
- If the chat side-pane is enabled, it is only displayed when a chat connection is running
- Added a "Logout..." item to the Community menu
- Individual pane sizes are now saved
- Server lists can now be pinged more than once (in dual-pane view)

19189 -> 19190
- Added vertical resizing to right hand panes
- Increased maximum server name length to 64 chars (previously 20)
- Added setting for single-pane or dual-pane
- Added delete function to dual pane
- Added double-click to connect to dual pane
- Fixed bug in chat server's handling of SQL results
- Fixed bug in chat server's remove_user function (Thanks: Shadz)
- Added optional side-bar for online users in chat instead of separate window

19188 -> 19189
- Added "Reply" function to incoming messages
- Export QSTAT list now works if the "Servers" parent list is selected
- Fixed taskbar flash when SQ is not active window
- Fixed message stack overflow in server
- Fixed buffer overflow in client; limited outgoing message size
- Fixed bug in server where user attributes were not initialized to zero
- Changed layout of Send/Receive message window
- Added horizontal resizing

19187 -> 19188
- Fixed a bug that prevented sub-lists from being exported in QSTAT format
- Fixed missing Unreal code in SQ->Qstat id conversion
- Added incoming message stack to client; received messages no longer appear immediately
- Added flashing "new message" icon

19186 -> 19187
- Added control-char encoding/decoding on client-side
- Added ability to export 'QSTAT' files (extension .qst); these are identical to the files found on the Server Query website
- Allowed setting of server names up to 64 chars long
- Enabled 'Set to hostname' checkbox in server properties
- Added sound effect to 'Incoming Message'; plays sounds/incoming.wav or default sound if not found

19185 -> 19186
- Fixed crash in chat server on invalid login info
- Stopped incoming message windows from coming to foreground while SQ is not the foreground app
- Fixed 128 byte limit on messages

19184 -> 19185
- Improved "Receive Message' Dialog
- Ensured that "Send Message' got focus on open

19183 -> 19184
- Added queueing facility to handle multiple server messages

19182 -> 19183
- Added basic "SQ Chat" interface

19181 -> 19182
- Added code to set working directory at startup to location of query.exe
- Adjust LAN server refresh period

19180 -> 19181
- Fixed bug where first time users would get a small window in the left hand corner of screen (thanks: Saint)
- New window was only showing up in Win2K; fixed for Win9x (thanks: Saint, Mutty)
- Set a default size if an invalid window size is saved for some reason (thanks: VRBones)
- Added dialog box to turn off name resolution if SQ was not shut down properly last run

19179 -> 19180
- Merged kingpin and sin code back into quake2.dll
- Added resizing window support
- Fixed bug that could cause Welcome message to appear twice
- SQ saves/restores window positioning and size

19178 -> 19179
- Fixed bug in halflife.dll that prevented player list from being displayed
- Eliminated bug in hash.c that would cause a crash upon program closure due to memory allocation occuring in a DLL and being freed by the EXE
- Added list control, servinfo.c for server info and player reporting

19177 -> 19178
- Added "SOF demo" support to quake2 dll
- Added "SOF demo" support to qstat dll (made new server type "SFS")
- Added /LAN command line switch to disable name resolution

19176 -> 19177
- Updated Half-life DLL to start hl.exe with correct "-game " parameter
- Added 'wait until spot available' option (or don't connect) when a server is full

19175 -> 19176
- Fixed crash when a http connection was unexpectedly closed (thanks: Shadz)
- slightly enlarged main window
- Changed 'Program Configuration' dialog box to default to type of current server
- Changed QStat 'Refresh List' to empty list when a user-requested refresh is performed
- Added check to ensure list/default.dll was loaded (thanks: Shadz)
- Changed 'Create New List' window to always select "Internet Servers" type by default
- Fixed "Grouped" support for QStat lists

19174 -> 19175
- Implemented proper list move up/move down
- Lists are now sorted correctly
- QStat lists no longer 'flicker' on updates
- Long hostnames are now shortened to 20 chars on the treeview
- moved imagelist_destroy() to after the main window was closed (for aesthetic reasons)

19173 -> 19174
- Fixed bug in QStatlist support that prevented some URL's from working
- Fixed a long standing bug in http.c that could cause invalid memory accesses
- Fixed QStat/Gamespy lists being 'collapsed' upon refresh

19172 -> 19173
- MOTD is not displayed on a fresh install
- Fixed crash when WinSock load failed (thanks: Shadz)
- Moved group types into separate DLLs
- Enter now connects to selected server (thanks: BAD)


19171 -> 19172
- added rudimentary Q3Master support ( pretty useless atm)
- increased limit on # of servers per list from 256 to 65536
- ran some profiling on query.exe, improved performance for large sets of servers
- added a simple caching mechanism to the hash code to further improve performance
- Added image masks so that the icons appear correctly on non-white backgrounds (thanks: GreyMATR)
- Simple 'Move Up/Move Down' function added for lists ( ** BROKEN ** )
- Eliminated crash when starting Query with missing DLLs

19170 -> 19171
- Fixed bug in 'Sort LAN servers by game type'
- Fixed bug where lists were not always marked as containing servers
- Fixed bug in treeview when moving from 1 server to no servers
- Fixed a few memory/resource leaks

191769 -> 19170
- Added Open/Save config menu options.  Allows multiple configuration files 
- Changed "LAN" list to be a standard list, apart from the proviso that only one "LAN" list can exist
- "LAN" List header is now stored in configuration files (although actual servers are not)
- Added 'Connect with parameters...' option on 'Server' shortcut menu (thanks: Mutty)

19168 -> 19169
- Fixed "double click" bug where double clicking anywhere in the treeview would connect to the selected server
- Added folder/server icons to the treeview
- Server Query now by default saves all configuration data to "default.sq", replacing the two tiered "query.dat" and "servers.dat" of previous versions

19167 -> 19168
- Full support for domainnames (as opposed to IP addresses)
- 'Fun name' stripping for Q3A
- Lots of little bitty bugs squished

19166 -> 19167
- Added ability for QStat lists to be grouped by game (ala LAN)
- Added error messages when trying to create a server with blank name or name that is same as other list
- Added support for command line parameters

19165 -> 19166
- Improved performance on deletion of large lists
- Fixed problem with 'Incoming Message' facility while offline
- Fixed bug that caused LAN servers to incorrectly timeout if the new mouse-wheel code was enabled
- Added option 'Program Not Found' window to bring up the Program Configuration window
- Many low-level fixes dealing with memory leaks and other problems (thanks Shadow)

19164 -> 19165
- Systray icon now restores SQ window if it was minimised/hidden
- increased maxhashes to 2048
- added optional subclassing of treeview that allows the mousewheel to scroll through the list of servers (instead of just moving the list up and down)
- Re-added ability to move servers up/down the list

19163 -> 19164
- HUGE (4 hours straight... urgh) re-write of Hash functions.  May not be 100% stable yet.
- Enabled web site menu items
- Recompiled all game DLL's due to new hash code
- Fixed show-stopper bug in DeleteServerList()
- Changed DLL's to use .exe's Hash storage instead of internally allocated storage.
- Very basic system tray code: must restart Query to enable changes.

19162 -> 19163
- Added conversion support for old-style 'PupServers' list (no need to delete servers.dat)
- 'Always on top' is enabled at start up if previously selected
- Removed 'maximise' button
- Added default 'help' to the player list upon program start up
- Added web site menu items to 'File' menu.  Grayed out for now.

19154 -> 19162
- Support for two 'URL-based' list types: QStat lists (such as the now-familiar 'PowerUp' list) and GameSpy-esque lists.
- Support for sub-lists, of any type.
- Simplified server information pane; option to enable separate 'full server info' window.
- Ability to delete any list (or sublist) (except 'LAN')
- New menus ('Server', 'List') provide access to the standard right-mouse menus.
- 'Incoming message' facility, for announcement of new versions etc.
- Revised 'About' box (click Query icon for the Server Query HP)
- 'Always on top' option.
- Ability to group LAN servers by game type.
- 'Refreshing servers' window now only appears when a Refresh is requested.
- Unreal Tournament support. (new DLL)
- Unreal/UT are not listed in the 'configure | programs' window, as Unreal servers are not connected to by starting the program directly. (new DLL)
- '[SA]' is no longer the default Clan ID (blank is given instead)
- Lots of menu items renamed, re-ordered.
- 'File | View | DM Flags' disabled completely.
- Improvements made to LAN performance.

