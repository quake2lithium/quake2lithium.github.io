Mouse Movement Recorder

Copyright (C) 2006  anir
Modified 2010 - Mark Cranness

Displays movements of the on-mouse-pad mouse and corresponding on-screen pointer movement.
Can be used to diagnose mouse pointer acceleration problems ('Enhance pointer precision').

Press Ctrl+C to exit/stop.
Double-click window heading to Maximize window.

Mouse data displayed includes:

- MOUSE MOVEMENT   = X and Y mouse input (collected using DirectInput)
- POINTER MOVEMENT = Pointer movement (calculated from changes in pointer location)
- FREQUENCY = Sample rate / mouse bus update rate in Hz (="per second")
- EnPtPr    = Is the 'Enhance pointer precision' option turned ON?

If you run Mouse Movement Recorder in the background while running a game, it will
tell you if that game turns acceleration ('Enhance pointer precision') on.
When 'Enhance pointer precision' is on, the EnPtPr column displays a red ON.
If 'Enhance pointer precision' has been on at any time, the EnPtPr column at the
bottom of the window will display in red.
Turn 'Enhance pointer precision' OFF, run Mouse Movement Recorder, run your game,
then look at the EnPtPr column at the bottom of the Mouse Movement Recorder window.
If the EnPtPr has a red background, then your game turns 'Enhance pointer precision'
ON and needs a fix.

NOTE: While a game is running, Mouse Movement Recorder may show many red and green
lines, if the game continually re-positions the pointer to the middle of the screen.
Those red and green lines do not mean that you have acceleration, they only mean that
the re-positioned pointer has confused Mouse Movement Recorder.

If your system is busy, sometimes there might be an occasional delay before Windows 
updates the on-screen pointer position and if that happens the POINTER MOVEMENT will 
lag behind the MOUSE MOVEMENT.