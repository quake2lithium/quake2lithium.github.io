INTRODUCTION:

 I have done alot of troubleshooting of various mice setups over the years and I currently use this process to evaluate if a mouse is setup correctly or not. This package I have assembled from components of the Cheesefix, the MarkC fix and Anir's accelfix.exe I also have included their original packages(Thanks Guys!). I currently use Windows XP SP3 and a Microsoft Intellimouse Explorer 3.0, but I have tested the fix on various other mice. I have not written this guide for people using Windows Vista or 7, however the testing is also valid in these operating systems. The MarkC_Windows7+Vista+XP_MouseFix_Builder_1.4.zip package should be used for these operating systems if a fix is needed after testing.


INITIAL TESTING:
 
 First browse to the chieffix\Mouse_Movement_Recorder folder and run the MouseMovementRecorder.exe. A terminal looking window should open and it will basically show you if your mouse has acceleration or negative acceleration. All you will need to do is move your mouse around on your desktop at first. If the window remains all black and white then there is at least no issue with your desktop mouse settings.


TRIAL AND ERROR:

 If it is showing red AND green check if the EnPtPr is ON or OFF at the lower right of the Mouse Movement Recorder window. If it shows as ON go to Control Panel > Mouse > Pointer Options and turn OFF Enhanced Pointer Precision and test again. 

 If it is showing only red OR only green then you most likely have adjusted your windows mouse sensitivity and you would need to put this back to defaults which is 50% or 6 on the slider also located in Control Panel > Mouse > Pointer Options and test again. If you change your windows sensitivity you basically scale your mouse and this is not something I would recommend from my experience.


FURTHER TESTING: 

 Normally once I have corrected the desktop issues my games are fine, but I suggest testing in a few games by opening the MouseMovementRecorder.exe on your desktop then enter a game and run around for 30 seconds or so. Immediately when you exit the game left click on the MouseMovementRecorder window once then hit the Pause/Break key on the keyboard, this will freeze the window and you will be able to scroll up and see if any red or green or pointer precision in the game. Continue to next section with or without RED&GREEN issue.


MOUSE CURVE: 

 Whether you are still experiencing RED&GREEN issues or not you will still need to apply a fix to correct the mouse curve issue. Always before applying any patches/fixes of this sort I would recommend that you back up your registry. If you are familiar with this you may backup then skip the next section.


BACKUP YOUR REGISTRY: 

 Click on START then RUN and type regedit and click OK. This is the windows registry editor, there are two panes left and right. In the left pane scroll all the way to the top and left click and highlight My Computer. Now at the top go to File > Export then name the backup todays date and time or whatever you like. Once the export is complete then we may move on.

 
INITIAL FIX:

 The first fix we are going to apply is the cplModified.reg originally found in the cheesefix package. This is the only other fix most people will need to correct the mouse curve and accel issues. Browse to the chieffix\Fixes_I_Use folder and run the cplModified.reg. Click Yes > OK > Reboot and test again.

 
ADDITIONAL FIX:

 If you are STILL experiencing RED&GREEN issues then we will try the the last fix which should remove all accel from windows. Browse to the chieffix\Fixes_I_Use folder and run the accelfix.exe. Click Yes > OK > Reboot and test again. If now during the testing you do not see all black and white then you are most likely touching the edges of the screen, your system is busy or it could just be your mouse. 


USB POLLING RATE:

 If all of the issues are resolved above and you have all black and white in the mouse movement recorder then you may want to adjust the usb polling rate for your mouse. This will allow you to use as much as 1000hz, however 1000hz on no mouse is as consistent as 500hz. Basically 125hz = 8ms(default), 250hz = 4ms(next best), 500hz = 2ms(best), and 1000hz(inconsistent) = 1ms. The difference in 8ms(125hz/default) and 1ms(1000hz) is fairly great, however the difference in 2ms and 1ms is almost non existent compared. I would recommend that you set yours to 500hz(if your mouse is capable). 


ADJUSTING POLLING RATE:

 Browse to chieffix\USB_Rate\hidusbf and run Setup.exe. I have included a screen shot located in the chieffix\USB_Rate folder, set your program just like the screen shot then click install service then restart. There is no need to actually restart your computer for this process. You can now verify the polling rate has been changed in the Mouse Movement Recorder. Now you should notice that your mouse is a lot more responsive and all around better. 

 If the mouse is not capable of 500hz you will most likely be able to tell as I have seen mice lose power or the cursor may freeze from time to time. You may also now show red or green again due to your mouse's inability to use 500hz. If all is still black and white I would suggest some testing in a game for a while. If it appears unstable for any reason you will need to repeat the last step and use 250hz. This will still be twice the speed of the default 125hz. 


GOOD LUCK:

 Well I hope I was able to help, so far all reports have been positive. If you are still having RED&GREEN issues... please read this document again and verify you have not missed any steps, if not then you may contact me in irc on GameSurge or EnterTheGame in #quakelive Thanks for reading and thank all of the original fix developers who led me to this process! dM|Chiefin|MrSD. 